#!"D:\Program Files\Python35\python.exe"
# EASY-INSTALL-ENTRY-SCRIPT: 'translate-toolkit==2.3.1','console_scripts','po2ts'
__requires__ = 'translate-toolkit==2.3.1'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('translate-toolkit==2.3.1', 'console_scripts', 'po2ts')()
    )
