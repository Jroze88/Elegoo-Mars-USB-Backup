<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
    <context>
        <name>Authorization</name>
        <message>
            <source>Validity time:  </source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>AutoLayoutJob</name>
        <message>
            <source>Automatic layout...</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>CheckUpdate</name>
        <message>
            <source>Detected a new version of ChiTuBox%1. Is it updated immediately?</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Current version: %1, release time: %2</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>1. Supported Simplified Chinese, Traditional Chinese, English
2. Added batch import model function
3. Supported cbddlp /photon /zip / SLC slice format, added.ChiTubox project format, OBJ model format
4. Added Ctrl + left mouse button to slowly move the view function
5. Added spherical support and more support settings
6. Added the function of adding support on the support, allowing setting the support cross starting height
7. Solved the error of model and support crossover
8. Switch to support mode, allowing custom model Z lift height
9. Solved the problem that the edge angle of the bottom skate is too small
10. Added bottom valve parameter options
11. Added the secondary editing function of the slice file
12. Added the function of generating 3D model files in reverse by slice files
13. Added functions such as undo, forward, screenshot and video recording
14. Added automatic typesetting of models, placement of models by face, model mirroring, etc.
15. Added a variety of slicing parameters, opening speed, distance, anti-aliasing and other parameter settings
16. Added hollowing and hole punching function
</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>V1.1.0
1. Supported Simplified Chinese, Traditional Chinese, English
2. Added batch import model function
3. Supported cbddlp /photon /zip / SLC slice format, added.ChiTubox project format, OBJ model format
4. Added Ctrl + left mouse button to slowly move the view function
5. Added spherical support and more support settings
6. Added the function of adding support on the support, allowing setting the support cross starting height
7. Solved the error of model and support crossover
8. Switch to support mode, allowing custom model Z lift height
9. Solved the problem that the edge angle of the bottom skate is too small
10. Added bottom valve parameter options
11. Added the secondary editing function of the slice file
12. Added the function of generating 3D model files in reverse by slice files
13. Added functions such as undo, forward, screenshot and video recording
14. Added automatic typesetting of models, placement of models by face, model mirroring, etc.
15. Added a variety of slicing parameters, opening speed, distance, anti-aliasing and other parameter settings
16. Added hollowing and hole punching function
</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Latest version: %1, release time: %2</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>CurrentMachinePara</name>
        <message>
            <source>None</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Grid3D</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cross3D</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cross3D-45</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>DigEmptyJob</name>
        <message>
            <source>Hollow...</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>DigHoleJob</name>
        <message>
            <source>Digging holes...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Fail!Not hollowed out or too deep to dig!</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>DockBar</name>
        <message>
            <source>Open project</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Save project</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Open file</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Save as</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Recently opened file</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Clear all</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Account</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Login in</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Authorization</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Language</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Help</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Check for updates</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Factory setting</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>About ChiTuBox</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Examples</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Quit</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save file</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Screen capture/recording</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Undo</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Redo</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Import the current model</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Auto layout</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Hollow</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Dig hole</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Edit model</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cutting</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Subregional slice</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Open Project</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save Project</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Open...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save As...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Open Recent</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Clear All</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Login</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Check For Updates</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Factory Setting</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Open File</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save File</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Screen Capture/Recording</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Load Current Model</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Auto Layout</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Dig Hole</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Open Log Path</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Collecting Data</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Plugins</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Clone Current Model</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>DockBarExp</name>
        <message>
            <source>Watermark</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Author:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Other:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Screen recording</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Capture(Ctrl+Shift+A)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Start</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Auto layout</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Center</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>X side</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Y side</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Min distance</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Hollow</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Wall thickness</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Precision</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Inner</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Outer</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Dig hole</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Circle</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Hexagon</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Square</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Size</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Keep the Hole</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Add a hole</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Edit mesh</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Smooth</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Sharp</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Brush diameter</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Brush height</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Convex</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Concave</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Triangle size</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Adjust triangle</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Reverse normal </source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cutting</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Add cutting surface</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Min distance:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Wall thickness:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Precision:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Shape:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Size:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Keep the hole</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Dig Hole</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Wall Thickness:</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>FeedBackDialog</name>
        <message>
            <source>Collecting Data</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Note：data gathered will be used in accordance with the ChiTuBox Privacy Policy(https://www.chitubox.com/legal.html)
</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>ChiTuBox will collect the following information to improve the software:
</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>DEVICE_ID
DEVICE_TYPE
SOFTWARE_ID
SOFTWARE_VERSION_ID
COUNTRY_NAME
</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Enable anonymized usage statistics.</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Note：data gathered will be used in accordance with the ChiTuBox Privacy Policy(https://www.chitubox.com/legal.html)</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>LicenceDialog</name>
        <message>
            <source>Authorization</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>ID</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Authorization code</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Confirm authorization</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>ID:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>License:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Confirm Authorization</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>LoginWin</name>
        <message>
            <source>Powerful, but easy to use!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>ChiTuBox</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Enter account</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Enter password</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Change
another</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Register</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Forget Password?</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Remember me</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Logout</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>login</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>MeshFaceSet</name>
        <message>
            <source>Refining the model grid</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>MeshLoaderBase</name>
        <message>
            <source>Loading file...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Writing file...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cann't open file!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cann't write file!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Invalid File!</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Cann't create directory!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Other error!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Writing File...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Invalid file!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Write successfully,&lt;a href=&quot;%1&quot; style='color:&quot;#4eaeee&quot;;text-decoration:none'&gt;open the file&lt;/a&gt;</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Write successfully,&lt;a href=&quot;%1&quot; style='color:&quot;#4eaeee&quot;'&gt;open the folder&lt;/a&gt;</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>MeshLoaderProxy</name>
        <message>
            <source>File does not exist!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Unable to open file!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Unable to write to file
:%1</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>MyFileDialog</name>
        <message>
            <source>Open file</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Save as</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Open project</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Save project</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Save slicer</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Save screenshot</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Save animation</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Select mask picture</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Import configuration</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Export configuration</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Open File</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save As</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Open Project</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save Project</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save Slicer</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save Screenshot</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save Animation</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Import Configuration</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Export Configuration</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Import Plugin</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Build Plugin</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>PluginsDialog</name>
        <message>
            <source>Plugins</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Name</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Type</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Input</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Output</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Author</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Email</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Detail</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Import Plugin</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Build Plugin</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Delete Plugin</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>PreViewArea</name>
        <message>
            <source>Machine name:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>File name:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Resin type:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Resin volume:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Resin weight:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Estimated price:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Print Time:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Export</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Back</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Exposure time(s):</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Bottom exposure time(s):</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Layer thickness(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Lifting distance(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Lifting speed(mm/min):</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Dropping speed(mm/min):</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Machine:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Resin:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Volume:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Weight:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Price:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Time:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Exposure Time(s):</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom Exposure Time(s):</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Layer Height(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lift Distance(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lift Speed(mm/min):</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Retract Speed(mm/min):</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>QObject</name>
        <message>
            <source>Unable to open file!</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>ReDialog</name>
        <message>
            <source>Parameter settings</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Machine settings</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Resin</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Distance &amp; speed</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Infill</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Gcode</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Advance</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Name:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Resolution:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>X:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Y:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lock ratio:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Size:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Z:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Machine type:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Mirror:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Resin type:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Exposure time:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Bottom exposure time:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Bottom light-off delay:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Light-off delay:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Resin density:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Resin cost:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Layer thickness:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Number of layers:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Bottom lift distance:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Lifting distance:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Bottom uplift speed:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Lifting speed:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Speed of decent:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Infill structure:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Infill density:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Wall thickness:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Start:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Interlayer:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>End:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom light intensity PWM:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Light intensity PWM:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Anti-aliasing:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Import configuration</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Export configuration</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Settings</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Machine</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Print</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lock Ratio:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Machine Type:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Resin Type:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Resin Density:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Resin Cost:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Layer Height:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom Layer Count:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Exposure Time:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom Exposure Time:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Light-off Delay:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom Light-off Delay:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom Lift Distance:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lifting Distance:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom Lift Speed:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lifting Speed:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Retract Speed:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Infill Structure:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Infill Density:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Wall Thickness:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom Light PWM:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Light PWM:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Anti-aliasing Level:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Import...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Export...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lift Distance:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Lift Speed:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>None</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>ReDialog0</name>
        <message>
            <source>Sent to the machine via netport or WIFI</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Equipment name:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Change device name:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Router hotspot:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Router password:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Configuring WIFI</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Equipment Name:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Change Device Name:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Router Hotspot:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Router Password:</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>ReNavBar</name>
        <message>
            <source>Top</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Middle</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Bottom</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Raft</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>SaveGifJob</name>
        <message>
            <source>Prepare...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Add picture %1</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Save to gif...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Write successfully,&lt;a href=&quot;%1&quot; style='color:&quot;#4eaeee&quot;'&gt;open the folder&lt;/a&gt;</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>SelectMachine</name>
        <message>
            <source>Please choose your machine:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>OK</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cancel</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>SideBar</name>
        <message>
            <source>File list:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Select all</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Parameter</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Slice</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Z-axis lift height(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Support setting:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Light</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Middle</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Heavy</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Auto support:</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Minimum length of support(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Support staggered starting height(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Automatic support density(%)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Automatic support angle(°)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>+Platform</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>+Everywhere</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Remove all</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>File List:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Select All</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Settings</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Z Lift Height(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Support Setting:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Auto Support:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Minimum Length(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cross Start Height(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Density(%)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Angle(°)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>+All</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Remove All</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Add Support</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Delete Support</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Edit Support</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Reset</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Collapse</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Expand</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Medium</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>SlicerJob</name>
        <message>
            <source>Slicing...</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>SupportPara</name>
        <message>
            <source>Sphere</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cone</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cube</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cylinder</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Prism</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Pyramid</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>None</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Skate</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>TabPage</name>
        <message>
            <source>Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Radius(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Length(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Contact depth(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Support angle(°):</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Contact Depth(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>TabPageSupportBottom</name>
        <message>
            <source>Platform contact shape</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Platform contact shape diameter(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Platform contact thickness</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Model contact shape</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Model contact diameter(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Model contact depth(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Platform Touch Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Touch Diameter(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Thickness</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Model Contact Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Contact Diameter(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Contact Depth(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Skate</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cone</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cube</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cylinder</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Prism</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>None</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Sphere</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>TabPageSupportMiddle</name>
        <message>
            <source>Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Diameter(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Prism</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cube</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cylinder</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>TabPageSupportRaft</name>
        <message>
            <source>Raft shape</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Raft density(%)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Raft thickness(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Raft height(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Raft slope(°)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Raft Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Raft Area Ratio(%)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Raft Thickness(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Raft Height(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Raft Slope(°)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>None</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Skate</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>TabPageSupportTip</name>
        <message>
            <source>Contact shape</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Contact shape diameter(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Connection shape</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Connection shape upper diameter(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Connection shape lower diameter(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Length(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Contact depth(mm)</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Contact Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Contact diameter(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Connection Shape</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Upper Diameter(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lower Diameter(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Connection Length(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Sphere</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>None</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Contact Depth(mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cone</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Pyramid</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Cube</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Skate</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>Temp</name>
        <message>
            <source>Title</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>text</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>tedfs</source>
            <translation type="obsolete">
            </translation>
        </message>
    </context>
    <context>
        <name>ToolsOperation</name>
        <message>
            <source>X:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Y:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Z:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Put on the bottom plate</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Centered</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Reset</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>+30°</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>-30°</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Flatten by face</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>         (mm)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>              (%)</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Lock ratio</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>X mirror</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Y mirror</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Z mirror</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Put on the plate</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>+15°</source>
            <translation type="unfinished">
             {15°?}</translation>
        </message>
        <message>
            <source>-15°</source>
            <translation type="unfinished">
             {15°?}</translation>
        </message>
    </context>
    <context>
        <name>UpdateDialog</name>
        <message>
            <source>Check for updates</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Yes</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Version log:</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Automatically check the latest version at startup</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Check For Updates</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>UserLogin</name>
        <message>
            <source>Account and password numbers cannot be empty!</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>Logging in ... ...</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Logging ... ...</source>
            <translation type="obsolete">
            </translation>
        </message>
        <message>
            <source>Loging ... ...</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>login successful</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>logout successful</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>ViewArea</name>
        <message>
            <source>Solid</source>
            <translation type="unfinished">
            </translation>
        </message>
        <message>
            <source>X-Ray</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
    <context>
        <name>ygAddSupport</name>
        <message>
            <source>Adding support.......</source>
            <translation type="unfinished">
            </translation>
        </message>
    </context>
</TS>