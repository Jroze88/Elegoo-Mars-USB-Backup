repare:
download python3.7 from www.python.org
https://www.python.org/ftp/python/3.7.1/python-3.7.1-amd64.exe
select add Python 3.7 to Path option after open installer

input command from cmd:
pip install translate-toolkit

How to add a new language?  (Windows only)
For example,you want to add french ,do the following step:
1. Down poedit  from  https://poedit.net/
2. open fr.po with poedit
3. edit the translation
4. convert .po to .ts with the command:po2ts.exe -i fr.po -o fr.ts
5. convert .ts to .qt with the command:../../lrelease.exe fr.ts -qm fr.qm
6. rename zh_CN.qm to zh_CN.qm.backup and rename fr.qm to zh_CN.qm,selecte simpled chinese and check the translation
7. send fr.po to  yiyu1234654@163.com ,we will add the language in the later version.
 